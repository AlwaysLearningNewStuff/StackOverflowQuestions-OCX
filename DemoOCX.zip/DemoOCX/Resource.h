//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by DemoOCX.rc
//

#define IDS_DEMOOCX               1
#define IDS_DEMOOCX_PPG           2

#define IDS_DEMOOCX_PPG_CAPTION   200

#define IDD_PROPPAGE_DEMOOCX      200


#define IDB_DEMOOCX               1


#define _APS_NEXT_RESOURCE_VALUE        201
#define _APS_NEXT_CONTROL_VALUE         201
#define _APS_NEXT_SYMED_VALUE           101
#define _APS_NEXT_COMMAND_VALUE         32768
